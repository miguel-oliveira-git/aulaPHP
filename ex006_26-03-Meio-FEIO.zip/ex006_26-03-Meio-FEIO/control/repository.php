<?php

define("ARQUIVO", "cadastro.json");

// global $ARQUIVO;
// $ARQUIVO = "cadastro.json";